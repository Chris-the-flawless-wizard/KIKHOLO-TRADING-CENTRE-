# How to put this on GitHub and Vercel

1. Download `chrisxchange-clean.zip`.
2. Unzip it.
3. On GitHub, open `Chris-the-flawless-wizard/KIKHOLO-TRADING-CENTRE-`.
4. Delete the old messy folders (`index html`, `index%20html`, `trading centre`) after you copy the new files.
5. Upload the new files to the repo root so `index.html` sits at the top, not inside another folder.
6. Commit the change.
7. Wait for Vercel to rebuild.

Until you push, the live site will still be the old version.
