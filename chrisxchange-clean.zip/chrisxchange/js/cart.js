document.addEventListener("DOMContentLoaded", async () => {
  const wrap = document.getElementById("cartWrap");
  const checkoutForm = document.getElementById("checkoutForm");
  if (!wrap) return;

  try {
    await CX.loadCatalog();
  } catch (err) {
    wrap.innerHTML = "<p>Could not load products.</p>";
    return;
  }

  function rows() {
    return CX.getCart().map((item) => {
      const product = CX.productById(item.id);
      if (!product) return null;
      return { ...item, product, line: product.price * item.qty };
    }).filter(Boolean);
  }

  function render() {
    const items = rows();
    if (!items.length) {
      wrap.innerHTML = '<div class="empty-catalogue"><h2>Your list is empty</h2><p>Add products from a store, then come back here.</p><p><a class="cta-primary" href="products.html">Browse products</a></p></div>';
      return;
    }
    const total = items.reduce((n, i) => n + i.line, 0);
    wrap.innerHTML = '<div class="cart-list">' + items.map((i) =>
      '<article class="cart-row">' +
      '<img src="' + CX.escape(i.product.image) + '" alt="">' +
      "<div><h3>" + CX.escape(i.product.name) + "</h3>" +
      "<p>" + CX.escape(CX.businessById(i.product.businessId)?.name || "") + "</p>" +
      "<strong>" + CX.money(i.product.price, i.product.currency) + "</strong></div>" +
      '<div class="cart-qty"><button data-minus="' + i.product.id + '">−</button>' +
      "<span>" + i.qty + "</span>" +
      '<button data-plus="' + i.product.id + '">+</button>' +
      '<button class="linkish" data-remove="' + i.product.id + '">Remove</button></div></article>'
    ).join("") + "</div>" +
    '<div class="cart-total"><span>Estimated total</span><strong>' + CX.money(total, "UGX") + "</strong></div>" +
    (checkoutForm ? "" : '<p class="cart-note">This is a shopping list, not live payment. Talk to the seller to confirm price and collect the item.</p><p><a class="cta-primary" href="checkout.html">Request items</a></p>');
  }

  wrap.addEventListener("click", (e) => {
    const minus = e.target.closest("[data-minus]");
    const plus = e.target.closest("[data-plus]");
    const remove = e.target.closest("[data-remove]");
    let cart = CX.getCart();
    if (minus) {
      cart = cart.map((i) => i.id === minus.dataset.minus ? { ...i, qty: i.qty - 1 } : i).filter((i) => i.qty > 0);
    } else if (plus) {
      cart = cart.map((i) => i.id === plus.dataset.plus ? { ...i, qty: i.qty + 1 } : i);
    } else if (remove) {
      cart = cart.filter((i) => i.id !== remove.dataset.remove);
    } else return;
    CX.saveCart(cart);
    CX.updateHeader();
    render();
  });

  checkoutForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const items = rows();
    if (!items.length) return;
    const order = {
      id: "ord-" + Date.now(),
      name: document.getElementById("buyerName").value.trim(),
      phone: document.getElementById("buyerPhone").value.trim(),
      note: document.getElementById("buyerNote").value.trim(),
      items: items.map((i) => ({ id: i.id, name: i.product.name, qty: i.qty, price: i.product.price })),
      total: items.reduce((n, i) => n + i.line, 0),
      createdAt: new Date().toISOString()
    };
    const orders = JSON.parse(localStorage.getItem(CX.KEYS.orders) || "[]");
    orders.unshift(order);
    localStorage.setItem(CX.KEYS.orders, JSON.stringify(orders));
    CX.saveCart([]);
    CX.updateHeader();
    wrap.innerHTML = '<div class="empty-catalogue"><h2>Request saved on this device</h2><p>No money was taken. Contact the seller to agree on payment and collection. Demo order ID: ' + CX.escape(order.id) + "</p><p><a class=\"cta-primary\" href=\"account.html\">View account</a></p></div>";
    checkoutForm.style.display = "none";
  });

  render();
});
