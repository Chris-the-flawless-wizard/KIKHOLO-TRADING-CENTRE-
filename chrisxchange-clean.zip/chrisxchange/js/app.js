/* CHRISXCHANGE shared app: theme, menu, auth header, cart badge, catalog helpers */
const CX = {
  KEYS: {
    theme: "chrisxchange-theme",
    users: "chrisxchange-users",
    session: "chrisxchange-session",
    cart: "chrisxchange-cart",
    orders: "chrisxchange-orders",
    businesses: "chrisxchange-user-businesses"
  },
  catalog: null
};

CX.money = function (amount, currency) {
  return new Intl.NumberFormat("en-UG", {
    style: "currency",
    currency: currency || "UGX",
    maximumFractionDigits: 0
  }).format(Number(amount) || 0);
};

CX.escape = function (value) {
  return String(value ?? "").replace(/[&<>"']/g, (m) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[m]));
};

CX.getUsers = () => JSON.parse(localStorage.getItem(CX.KEYS.users) || "[]");
CX.saveUsers = (users) => localStorage.setItem(CX.KEYS.users, JSON.stringify(users));
CX.getSession = () => {
  try { return JSON.parse(localStorage.getItem(CX.KEYS.session) || "null"); }
  catch { return null; }
};
CX.setSession = (user) => {
  if (!user) localStorage.removeItem(CX.KEYS.session);
  else localStorage.setItem(CX.KEYS.session, JSON.stringify({
    id: user.id, name: user.name, email: user.email, role: user.role
  }));
};
CX.getCart = () => JSON.parse(localStorage.getItem(CX.KEYS.cart) || "[]");
CX.saveCart = (cart) => localStorage.setItem(CX.KEYS.cart, JSON.stringify(cart));
CX.cartCount = () => CX.getCart().reduce((n, item) => n + Number(item.qty || 0), 0);

CX.addToCart = function (productId, qty) {
  const cart = CX.getCart();
  const found = cart.find((item) => item.id === productId);
  if (found) found.qty += qty || 1;
  else cart.push({ id: productId, qty: qty || 1 });
  CX.saveCart(cart);
  CX.updateHeader();
  return cart;
};

CX.loadCatalog = async function () {
  if (CX.catalog) return CX.catalog;
  const res = await fetch("data/catalog.json");
  if (!res.ok) throw new Error("Could not load catalogue");
  CX.catalog = await res.json();
  return CX.catalog;
};

CX.productById = function (id) {
  return CX.catalog?.products.find((p) => p.id === id);
};

CX.businessById = function (id) {
  return CX.catalog?.businesses.find((b) => b.id === id);
};

CX.categoryById = function (id) {
  return CX.catalog?.categories.find((c) => c.id === id);
};

function applyTheme() {
  const saved = localStorage.getItem(CX.KEYS.theme);
  if (saved === "light") document.body.classList.add("light-mode");
}

function updateThemeButton() {
  const btn = document.getElementById("themeToggle");
  if (!btn) return;
  const icon = btn.querySelector("i");
  const isLight = document.body.classList.contains("light-mode");
  if (icon) icon.className = isLight ? "fa-solid fa-sun" : "fa-solid fa-moon";
  btn.setAttribute("aria-label", isLight ? "Switch to dark mode" : "Switch to light mode");
}

CX.updateHeader = function () {
  const session = CX.getSession();
  const loginLink = document.getElementById("headerLogin");
  const signupLink = document.getElementById("headerSignup");
  const accountLink = document.getElementById("headerAccount");
  const cartCount = document.getElementById("cartCount");
  if (cartCount) cartCount.textContent = String(CX.cartCount());
  if (session) {
    if (loginLink) loginLink.style.display = "none";
    if (signupLink) {
      signupLink.textContent = session.name.split(" ")[0];
      signupLink.href = "account.html";
    }
    if (accountLink) accountLink.style.display = "";
  } else if (accountLink) {
    accountLink.style.display = "none";
  }
};

document.addEventListener("DOMContentLoaded", () => {
  applyTheme();
  updateThemeButton();
  CX.updateHeader();

  const themeToggle = document.getElementById("themeToggle");
  const menuToggle = document.getElementById("menuToggle");
  const nav = document.querySelector("header nav");

  themeToggle?.addEventListener("click", () => {
    document.body.classList.toggle("light-mode");
    localStorage.setItem(
      CX.KEYS.theme,
      document.body.classList.contains("light-mode") ? "light" : "dark"
    );
    updateThemeButton();
  });

  if (menuToggle && nav) {
    menuToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("mobile-open");
      menuToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      const icon = menuToggle.querySelector("i");
      if (icon) icon.className = isOpen ? "fa-solid fa-xmark" : "fa-solid fa-bars";
    });
    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("mobile-open");
        menuToggle.setAttribute("aria-expanded", "false");
        const icon = menuToggle.querySelector("i");
        if (icon) icon.className = "fa-solid fa-bars";
      });
    });
  }
});
