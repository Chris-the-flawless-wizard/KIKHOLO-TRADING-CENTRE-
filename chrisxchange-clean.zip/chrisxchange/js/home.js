document.addEventListener("DOMContentLoaded", async () => {
  const searchForm = document.getElementById("homeSearchForm");
  const searchInput = document.getElementById("searchInput");
  const shopBox = document.getElementById("shopContainer");
  const statProducts = document.getElementById("statProducts");
  const statBusinesses = document.getElementById("statBusinesses");
  const statCategories = document.getElementById("statCategories");

  searchForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = (searchInput?.value || "").trim();
    location.href = "products.html" + (q ? ("?q=" + encodeURIComponent(q)) : "");
  });

  try {
    const catalog = await CX.loadCatalog();
    if (statProducts) statProducts.textContent = String(catalog.products.length);
    if (statBusinesses) statBusinesses.textContent = String(catalog.businesses.length);
    if (statCategories) statCategories.textContent = String(catalog.categories.length);

    if (shopBox) {
      shopBox.innerHTML = catalog.categories.map((cat) => {
        const biz = catalog.businesses.find((b) => b.category === cat.id);
        const count = catalog.products.filter((p) => p.category === cat.id).length;
        const cover = catalog.products.find((p) => p.category === cat.id && p.featured)?.image
          || catalog.products.find((p) => p.category === cat.id)?.image
          || "";
        return '<div class="shop-card" data-search="' + CX.escape((cat.name + " " + (biz?.name || "") + " " + cat.blurb).toLowerCase()) + '">' +
          '<a href="store.html?category=' + cat.id + '"><img src="' + CX.escape(cover) + '" alt="' + CX.escape(cat.name) + '" loading="lazy"></a>' +
          "<h3>" + CX.escape(cat.name) + "</h3>" +
          "<p>" + CX.escape(cat.blurb) + "</p>" +
          "<p class=\"shop-meta\">" + CX.escape(biz ? biz.name : "Local store") + " · " + count + " products</p>" +
          '<a href="store.html?category=' + cat.id + '"><button type="button">Visit Store</button></a></div>';
      }).join("");
    }

    searchInput?.addEventListener("input", () => {
      const q = searchInput.value.toLowerCase().trim();
      document.querySelectorAll(".shop-card").forEach((card) => {
        card.style.display = !q || (card.dataset.search || "").includes(q) ? "" : "none";
      });
    });
  } catch (err) {
    if (shopBox) shopBox.innerHTML = "<p>Could not load stores. Check that data/catalog.json is online.</p>";
  }
});
