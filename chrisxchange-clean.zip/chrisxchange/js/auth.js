document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");
  const businessForm = document.getElementById("businessForm");
  const logoutBtn = document.getElementById("logoutBtn");
  const message = document.getElementById("formMessage");

  function show(text, ok) {
    if (!message) return;
    message.textContent = text;
    message.className = "form-message " + (ok ? "ok" : "err");
  }

  loginForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value;
    const user = CX.getUsers().find((u) => u.email === email && u.password === password);
    if (!user) {
      show("No account matches that email and password. Create one first.");
      return;
    }
    CX.setSession(user);
    show("Welcome back, " + user.name + ".", true);
    setTimeout(() => { location.href = "account.html"; }, 600);
  });

  registerForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value;
    const role = document.querySelector("[name=role]:checked")?.value || "customer";
    if (password.length < 6) {
      show("Use a password with at least 6 characters.");
      return;
    }
    const users = CX.getUsers();
    if (users.some((u) => u.email === email)) {
      show("That email is already registered. Try logging in.");
      return;
    }
    const user = { id: "u-" + Date.now(), name, email, password, role, createdAt: new Date().toISOString() };
    users.push(user);
    CX.saveUsers(users);
    CX.setSession(user);
    show("Account created. This demo saves data only in your browser.", true);
    setTimeout(() => { location.href = role === "business" ? "register-business.html" : "account.html"; }, 700);
  });

  businessForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const session = CX.getSession();
    if (!session) {
      show("Create an account or log in first.");
      return;
    }
    const listing = {
      id: "biz-" + Date.now(),
      ownerId: session.id,
      name: document.getElementById("bizName").value.trim(),
      category: document.getElementById("bizCategory").value,
      area: document.getElementById("bizArea").value.trim(),
      phone: document.getElementById("bizPhone").value.trim(),
      description: document.getElementById("bizDesc").value.trim(),
      createdAt: new Date().toISOString()
    };
    const list = JSON.parse(localStorage.getItem(CX.KEYS.businesses) || "[]");
    list.unshift(listing);
    localStorage.setItem(CX.KEYS.businesses, JSON.stringify(list));
    const users = CX.getUsers().map((u) => u.id === session.id ? { ...u, role: "business" } : u);
    CX.saveUsers(users);
    CX.setSession(users.find((u) => u.id === session.id));
    show("Business saved on this device. It is a demo listing until a real database is connected.", true);
    setTimeout(() => { location.href = "account.html"; }, 900);
  });

  logoutBtn?.addEventListener("click", () => {
    CX.setSession(null);
    location.href = "index.html";
  });
});
