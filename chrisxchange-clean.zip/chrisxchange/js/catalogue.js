document.addEventListener("DOMContentLoaded", async () => {
  const grid = document.getElementById("productGrid");
  const status = document.getElementById("productStatus");
  const search = document.getElementById("productSearch");
  const sort = document.getElementById("sortProducts");
  const filters = document.getElementById("categoryFilters");
  const title = document.getElementById("catalogueTitle");
  const subtitle = document.getElementById("catalogueSubtitle");
  const shopName = document.getElementById("shopName");
  const shopMeta = document.getElementById("shopMeta");

  const params = new URLSearchParams(location.search);
  let category = (params.get("category") || "all").toLowerCase();
  const qParam = params.get("q") || "";
  if (search && qParam) search.value = qParam;

  let catalog;
  try {
    catalog = await CX.loadCatalog();
  } catch (err) {
    if (status) status.innerHTML = "<strong>Catalogue could not load.</strong><br>" + CX.escape(err.message);
    return;
  }

  const valid = catalog.categories.some((c) => c.id === category);
  if (!valid) category = "all";

  const catInfo = CX.categoryById(category);
  const business = catalog.businesses.find((b) => b.category === category);

  if (title) title.textContent = catInfo ? catInfo.name : "All Products";
  if (subtitle) {
    subtitle.textContent = catInfo
      ? catInfo.blurb + " Sample catalogue for Kikholo Trading Centre."
      : "Browse every listed product on CHRISXCHANGE.";
  }
  if (shopName && business) shopName.textContent = business.name;
  if (shopMeta && business) {
    shopMeta.innerHTML = CX.escape(business.area) + " · " + CX.escape(business.hours) +
      ' · <a href="https://wa.me/' + CX.escape(business.whatsapp) + '" target="_blank" rel="noopener">WhatsApp seller</a>';
  }

  function matches(product, query) {
    if (!query) return true;
    const businessName = CX.businessById(product.businessId)?.name || "";
    return [product.name, product.description, product.category, businessName]
      .join(" ").toLowerCase().includes(query);
  }

  function renderFilters() {
    if (!filters) return;
    const cats = ["all", ...catalog.categories.map((c) => c.id)];
    filters.innerHTML = cats.map((id) => {
      const label = id === "all" ? "All" : (CX.categoryById(id)?.name || id);
      return '<button class="category-filter ' + (category === id ? "active" : "") + '" data-cat="' + id + '">' + CX.escape(label) + "</button>";
    }).join("");
    filters.querySelectorAll("button").forEach((btn) => {
      btn.onclick = () => {
        category = btn.dataset.cat;
        const url = new URL(location.href);
        if (category === "all") url.searchParams.delete("category");
        else url.searchParams.set("category", category);
        history.replaceState({}, "", url);
        const info = CX.categoryById(category);
        if (title) title.textContent = info ? info.name : "All Products";
        render();
        renderFilters();
      };
    });
  }

  function render() {
    const query = (search?.value || "").toLowerCase().trim();
    let list = catalog.products.filter((p) => (category === "all" || p.category === category) && matches(p, query));
    const sortBy = sort?.value || "featured";
    if (sortBy === "low") list.sort((a, b) => a.price - b.price);
    if (sortBy === "high") list.sort((a, b) => b.price - a.price);
    if (sortBy === "name") list.sort((a, b) => a.name.localeCompare(b.name));
    if (sortBy === "featured") list.sort((a, b) => Number(b.featured) - Number(a.featured));

    if (status) {
      status.textContent = list.length
        ? list.length + " product" + (list.length === 1 ? "" : "s") + " found"
        : "No products match that search.";
    }
    if (!grid) return;
    if (!list.length) {
      grid.innerHTML = '<div class="empty-catalogue"><i class="fa-solid fa-box-open" style="font-size:2rem"></i><h2>No products found</h2><p>Try another search or category.</p></div>';
      return;
    }
    grid.innerHTML = list.map((p) => {
      const biz = CX.businessById(p.businessId);
      return '<article class="product-card-cx">' +
        '<img src="' + CX.escape(p.image) + '" alt="' + CX.escape(p.name) + '" loading="lazy">' +
        '<div class="product-body">' +
        '<span class="product-category">' + CX.escape(CX.categoryById(p.category)?.name || p.category) + "</span>" +
        "<h3>" + CX.escape(p.name) + "</h3>" +
        '<p class="product-desc">' + CX.escape(p.description) + "</p>" +
        '<p class="product-seller">' + CX.escape(biz ? biz.name : "Local seller") + "</p>" +
        '<div class="product-price">' + CX.money(p.price, p.currency) + "</div>" +
        '<div class="product-actions">' +
        '<a href="product.html?id=' + encodeURIComponent(p.id) + '">View</a>' +
        '<button type="button" data-add="' + CX.escape(p.id) + '">Add to list</button>' +
        "</div></div></article>";
    }).join("");

    grid.querySelectorAll("[data-add]").forEach((btn) => {
      btn.addEventListener("click", () => {
        CX.addToCart(btn.dataset.add, 1);
        btn.textContent = "Added";
        setTimeout(() => { btn.textContent = "Add to list"; }, 1200);
      });
    });
  }

  renderFilters();
  render();
  search?.addEventListener("input", render);
  sort?.addEventListener("change", render);
});
