# CHRISXCHANGE

**Kikholo Trading Centre** — Uganda’s digital marketplace.

Public name: **CHRISXCHANGE**  
Place name: **Kikholo Trading Centre**  
Tagline: **Connect. Discover. Trade.**

This folder is a cleaned rebuild of the old `KIKHOLO-TRADING-CENTRE-` project. One name, one file structure, one store page, and a real sample catalogue.

## What changed

| Before | After |
|---|---|
| README said Kikholo Hub, site said CHRISXCHANGE | One brand everywhere |
| Folders `index html`, `index%20html`, `trading centre` | No spaces in folder names |
| 8 copied `store-*.html` files | One `store.html?category=phones` |
| Search only hid homepage cards | Search opens the product catalogue |
| “1000+ products” with no list | Stats come from `data/catalog.json` (32 sample products, 8 stores) |
| Login pages in a broken folder | `login.html`, `register.html`, `account.html` |
| Brochure only | Demo list, demo account, demo business form |

Old store links such as `store-electronics.html` still work. They redirect to the new store page.

## Folder structure

```
chrisxchange/
├── index.html
├── products.html
├── product.html
├── store.html
├── cart.html
├── checkout.html
├── login.html
├── register.html
├── register-business.html
├── account.html
├── reels.html
├── assets/chrisxchange-logo.svg
├── css/style.css
├── css/products.css
├── css/reels.css
├── css/pages.css
├── js/app.js
├── js/home.js
├── js/catalogue.js
├── js/auth.js
├── js/cart.js
├── js/reels.js
└── data/catalog.json
```

## Run locally

1. Open the folder in VS Code.
2. Use Live Server on `index.html`.
3. Or from this folder run: `python3 -m http.server 5500`
4. Visit `http://localhost:5500`

`data/catalog.json` must be served over http. Opening the file directly as `file://` can block the catalogue.

## Demo features

- Search products and stores
- Filter by category
- Add items to a shopping list
- Create an account (saved in this browser only)
- Register a demo business
- Reels upload (this browser only)

There is **no live payment**. Checkout only saves a request on the device. Sample phone numbers are placeholders.

## Publish on Vercel

1. Copy every file in this folder over your GitHub repo (replace the messy folders).
2. Commit and push to `main`.
3. Vercel will redeploy https://kikholo-trading-centre.vercel.app

Suggested future repo name: `chrisxchange` (no trailing hyphen).

## Next real-world step

Connect a database (Firebase or Supabase) so accounts and products are shared between visitors, not stored only in one browser.

## Developer

Chris Mukhwana

MIT License
